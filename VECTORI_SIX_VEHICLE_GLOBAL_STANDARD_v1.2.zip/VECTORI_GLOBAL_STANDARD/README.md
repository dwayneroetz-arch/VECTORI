# VECTORI Global Standard — South Africa Edition

## What this is
A strengthened VECTORI browser prototype focused on the South African vehicle-buying journey, with global-standard comparison and ownership concepts.

## Run
Open `index.html` in a modern browser. No build step is required.

## Main features
- Vehicle search/filter/sort
- Compare up to six vehicles
- Market-position indicator
- Ownership and affordability calculator
- Balloon/residual finance model
- Admin and initiation fee modelling
- Cash-flow affordability and debt-service screening
- Stress testing
- Decision intelligence with explicit warnings/positives
- SA purchase-readiness checklist
- Dealer onboarding portal
- Six responsive advertising formats and 70/30 desktop ad allocation
- Viewability-aware ad impression tracking
- Evidence/provenance hierarchy
- Print purchase-intelligence report

## Advertising
The demo contains placeholder campaigns. Replace them with contracted advertiser creative, destination URLs and a production ad server/analytics layer before commercial use.

## Data/legal
The prototype deliberately does not scrape marketplaces. Production inventory should enter through authorised dealer/licensed feeds. Personal information should be minimised and processed under an appropriate POPIA-compliant architecture.

## Test
Run:
`node tests/test_vectori.js`

The included regression suite covers the zero/standard PMT calculation, operating-cost calculation, depreciation treatment, balloon-payment behaviour and monotonic response to higher fuel prices.

## Production note
This is a polished front-end/demo upgrade, not a claim that production readiness has been completed. Connect it to the commercial backend, production data contracts, security, privacy, advertising, monitoring and legal controls before launch.


## Inventory v1.2
The demo inventory contains 153 vehicles: 150 imported development records from the supplied CSV plus 3 previously supplied historical listing examples. URL paths are used only to recover make/model/variant display identity where those CSV columns were blank. Missing dealer, location, consumption, ownership, service-history, warranty and market fields remain explicitly missing. Source URLs and provenance are retained per record.
